﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoGuruSelenium.Helpers
{
    internal class ExcelData
    {
        public string FirstName;
        public string LastName;
        public string Phone;
        public string Email;
        public string Address;
        public string City;
        public string State;
        public string PostalCode;
        public string UserName;
        public string Password;
        public string ConfirmPassword;


    }
}
