﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herokuapp.Utilities
{
    internal class AddData
    {
        public string? FirstName;
        public string? LastName;
        public string? Email;
        public string? Dob;
        public string? City;
        public string? Street1;
        public string? Street2;
        public string? Phone;
        public string? PostalCode;
        public string? Country;
        public string? State;
    }
}
